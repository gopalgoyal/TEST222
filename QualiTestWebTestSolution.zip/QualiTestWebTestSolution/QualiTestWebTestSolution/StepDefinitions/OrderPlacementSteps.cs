﻿using QualiTestWebTestSolution.Configuration;
using QualiTestWebTestSolution.Locators;
using System;
using TechTalk.SpecFlow;

namespace QualiTestWebTestSolution.StepDefinitions
{
    [Binding]
    public class OrderPlacementSteps : Base
    {
        OrderPlacementLocators OP = new OrderPlacementLocators();

        [Given(@"go to website")]
        public void GivenGoToWebsite()
        {
            openUrl(getConfigVal("WEBSITE"));
        }

        [Then(@"Home page appears")]
        public void ThenHomePageAppears()
        {
            Match(dr.Title, "My Store", "Match page title");
        }

        [When(@"click on Tshirt button")]
        public void WhenClickOnTshirtButton()
        {
            ClickEl(OP.Tshirt);
        }
        

        [Then(@"select tshrit and add to the cart")]
        public void ThenSelectTshritAndAddToTheCart()
        {
            hoverOn(OP.hoverProduct);
            ClickEl(OP.addCart);
        }

        [When(@"click on Proceed to checkout")]
        public void WhenClickOnProceedToCheckout()
        {
            ClickEl(OP.proceedCheckout);
        }

        [Then(@"Summary page appears")]
        public void ThenSummaryPageAppears()
        {
            Match(dr.Title, "Order - My Store", "Match page title");
        }
        [When(@"click on Proceed to checkout on Summary")]
        public void WhenClickOnProceedToCheckoutOnSummary()
        {
            ClickEl(OP.summCheckout);
        }


        [Then(@"Signin page appears")]
        public void ThenSigninPageAppears()
        {
            Match(dr.Title, "Login - My Store", "Match page title");
        }

        [When(@"enter emailaddr and password")]
        public void WhenEnterEmailaddrAndPassword()
        {
            typeText(OP.usrNm, getConfigVal("EMAIL"));
            typeText(OP.passwd, getConfigVal("PASSWORD"));
        }

        [When(@"click on signin button")]
        public void WhenClickOnSigninButton()
        {
            ClickEl(OP.signIn);
        }

        [Then(@"Address page appears")]
        public void ThenAddressPageAppears()
        {
            Match(dr.Title, "Order - My Store", "Match page title");
        }
        [When(@"click on Proceed to checkout on Address")]
        public void WhenClickOnProceedToCheckoutOnAddress()
        {
            ClickEl(OP.addrCheckout);
        }

        [Then(@"shipping page appears")]
        public void ThenShippingPageAppears()
        {
            Match(getText(OP.shipHeading), "Shipping", "Match page heading");
        }

        [When(@"select the checkbox to agree terms")]
        public void WhenSelectTheCheckboxToAgreeTerms()
        {
            ClickEl(OP.terms);
        }

        [When(@"click on Proceed to checkout on Shipping")]
        public void WhenClickOnProceedToCheckoutOnShipping()
        {
            ClickEl(OP.shipCheckout);
        }
        [Then(@"payment screen appears")]
        public void ThenPaymentScreenAppears()
        {
            Match(getText(OP.paymentHeading), "Please choose your payment method", "Match page heading");
        }

        [When(@"select the payment (.*)")]
        public void WhenSelectThePayment(string paymentTyp)
        {
            if (paymentTyp.Equals("PaymentbyCheck"))
                ClickEl(OP.paybyCheck);
            else
                ClickEl(OP.paybyWire);
        }

        [Then(@"OrderSummary page appears")]
        public void ThenOrderSummaryPageAppears()
        {
            //
        }

        [When(@"click on confirm order button")]
        public void WhenClickOnConfirmOrderButton()
        {
            ClickEl(OP.confOrder);
        }

        [Then(@"OrderConfirmation page appears")]
        public void ThenOrderConfirmationPageAppears()
        {
            LogIt(getText(OP.successMsg), logTyp.Pass);
        }

        [When(@"click on view my customer account")]
        public void WhenClickOnViewMyCustomerAccount()
        {
            ClickEl(OP.custAcc);
        }

        [Then(@"My Account page appears")]
        public void ThenMyAccountPageAppears()
        {
            Match(getText(OP.paymentHeading), "My account", "Match page heading");
        }

        [When(@"click on Order History and Details")]
        public void WhenClickOnOrderHistoryAndDetails()
        {
            ClickEl(OP.orderHistory);
        }

        [Then(@"Order History page appears")]
        public void ThenOrderHistoryPageAppears()
        {
            Match(getText(OP.orderHistoryHeading), "Order history", "Match page heading");
        }

        [Then(@"verify newly placed order details")]
        public void ThenVerifyNewlyPlacedOrderDetails()
        {
            
        }

    }
}
