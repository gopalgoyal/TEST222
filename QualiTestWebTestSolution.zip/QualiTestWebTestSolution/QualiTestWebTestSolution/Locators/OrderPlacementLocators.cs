﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QualiTestWebTestSolution.Locators
{
    class OrderPlacementLocators
    {
        public string Tshirt = "//*[@id='block_top_menu']/ul/li/a[text()= 'T-shirts']";
        public string addCart = "//a[@title='Add to cart']";
        public string hoverProduct = "//a[@class='product_img_link']";
        public string proceedCheckout = "//a[@title='Proceed to checkout']";
        public string summCheckout = "//*[@id='center_column']//a[@title='Proceed to checkout']";

        public string usrNm = "email";
        public string passwd = "passwd";
        public string signIn = "SubmitLogin";

        public string addrCheckout = "//*[@name='processAddress']";
        public string shipHeading = "//*[@id='carrier_area']/h1[text() = 'Shipping']";
        public string shipCheckout = "//button[@name='processCarrier']";
        public string terms = "cgv";
        public string paymentHeading = "//*[@id='center_column']/h1[text() = 'Please choose your payment method']";
        public string paybyCheck = "//a[@title ='Pay by check.']";
        public string paybyWire = "//a[@title ='Pay by bank wire']";
        public string confOrder = "//*[@id='cart_navigation']/button[@type ='submit']";
        public string successMsg = "//div[@class='box order-confirmation']";

        public string custAcc = "//a[@class ='account']";
        public string accHeading = "//*[@id='center_column']/h1[text() = 'My account']";
        public string orderHistory = "//a[@title ='Orders']";
        public string orderHistoryHeading = "//*[@id='center_column']/h1[text() = 'Order history']";
        public string orderHistoryTbl = "order-list";

    }
}
